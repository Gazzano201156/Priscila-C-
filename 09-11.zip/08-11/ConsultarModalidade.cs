﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Estudio
{
    public partial class ConsultarModalidade : Form
    {
        int op = 0;
        public ConsultarModalidade( int op)
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;

            this.op = op;

            Modalidade cad = new Modalidade();
            MySqlDataReader r = cad.ConsultaModalidade();
            while(r.Read())
                comboBox1.Items.Add(r["Descricao Modalidade"].ToString());
            DAO_Conexao.con.Close();

            if (op == 2)
                btnAtualizar.Visible = true;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void ConsultarModalidade_Load(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Modalidade cad = new Modalidade(comboBox1.Text);
            MySqlDataReader r = cad.ConsultaModalidade();
            if (r.Read())
            {
                txtPrecosAtualizada.Text = r["Preço Modalidade"].ToString();
                txtQntdAlunoAtualiza.Text = r["Quantidade de Alunos"].ToString();
                txtQntdAulasAtualiza.Text = r["Quantidade de aulas"].ToString();
            }
            if (op== 1)
            {
                txtPrecosAtualizada.Enabled = false;

                txtQntdAlunoAtualiza.Enabled = false;
                txtQntdAulasAtualiza.Enabled = false;
            }
         
            Modalidade modalidade = new Modalidade(comboBox1.Text);
            MySqlDataReader resu = modalidade.consultarTodasModalidade();

            while (resu.Read())
            {
                comboBox1.Items.Add(resu["Descricao"].ToString());
            }
            DAO_Conexao.con.Close();

            }
    
    

        private void ConsultaModalidade(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
