﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Estudio
{
    class Modalidade
    {
        //08-11
        private string descricao;
        private float preco;
        private int qntdAluno;
        private int qntdAulas;
        private string text;

        public string Descricao { get => descricao; set => descricao = value; }
        public float Preco { get => preco; set => preco = value; }
        public int QntdAulas { get => qntdAulas; set => qntdAulas = value; }
        public int QntdAluno { get => qntdAluno; set => qntdAluno = value; }

        
        public Modalidade()
        {
        }

        public Modalidade(string text)
        {
            descricao = text;
        }

        public Modalidade(string descricao, float preco, int qtdealuno, int qtdeaula) {
            this.descricao = descricao;
            this.preco = preco;
            qntdAluno = qtdealuno;
            qntdAulas = qtdeaula;
        }

        public MySqlDataReader ConsultaModalidade()
        {
            MySqlDataReader res = null;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consulta = new MySqlCommand("SELECT * FROM Estudio_Modalidade WHERE descricaoModalidade = '" + descricao + "'", DAO_Conexao.con);
                res = consulta.ExecuteReader();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                //DAO_Conexao.con.Close(); 
            }
            return res;
        }

        public bool cadastrarModalidade()
        {
            bool cad = false;
            try
            {
                DAO_Conexao.con.Open();
               // Console.WriteLine("insert into Estudio_Modalidade (descricaoModalidade, precoModalidade, qntdAluno, qntdAulas) values ('" + descricao + "'," + preco + "," + qntdAluno + "," + qntdAulas + ")");
                //MySqlCommand insere = new MySqlCommand//("insert into Estudio_Modalidade (descricaoModalidade, precoModalidade, qntdAluno, qntdAulas) values ('" + descricao + "'," + preco + "," + qntdAluno + "," + qntdAulas +")", DAO_Conexao.con);
                MySqlCommand insere = new MySqlCommand("insert into Estudio_Modalidade (descricaoModalidade, precoModalidade, qntdAluno, qntdAulas) values ('" + descricao + "' ," + preco +","+ qntdAluno + "," +qntdAulas +")", DAO_Conexao.con);


                insere.ExecuteNonQuery();
                cad = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return cad;
        }



        public MySqlDataReader consultarTodasModalidade()
        {
            MySqlDataReader resultado = null;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand consulta = new MySqlCommand("SELECT * FROM Estudio_Modalidade", DAO_Conexao.con);
                resultado = consulta.ExecuteReader();
                Console.WriteLine(resultado.FieldCount);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                //DAO_Conexao.con.Close(); 
            }
            return resultado;
        }

        public bool atualizarModalidade()
        {
            bool atualiza = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand atualizar = new MySqlCommand("update Estudio_Modalidade set precoModalidade = " + preco + ", qtdeAlunos = " + qntdAluno + ", qtdeAulas = " + qntdAulas + " where descricaoModalidade = '" + descricao + "'", DAO_Conexao.con);
                atualizar.ExecuteNonQuery();
                atualiza = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return atualiza;
        }

        public bool excluirModalidade()
        {
            bool exclusao = false;
            try
            {
                DAO_Conexao.con.Open();
                MySqlCommand exclui = new MySqlCommand("update Estudio_Modalidade set ativa = 1 where descricaoModalidade = '" + descricao + "'", DAO_Conexao.con);
                exclui.ExecuteNonQuery();
                exclusao = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                DAO_Conexao.con.Close();
            }
            return exclusao;
        }
    }
       
 }