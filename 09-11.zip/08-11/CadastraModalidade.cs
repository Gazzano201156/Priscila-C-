﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Estudio
{
    public partial class CadastraModalidade : Form
    {
        public CadastraModalidade()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void GroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void bntCadastrar_Click(object sender, EventArgs e)
        {
            Modalidade modalidade= new Modalidade (textBox1.Text, float.Parse(textBox2.Text), int.Parse(txtQntdAlunos.Text), int.Parse(txtQntdAula.Text));
            if (modalidade.cadastrarModalidade())
                MessageBox.Show("Cadastrado");
            else
                MessageBox.Show("Erro");
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtQntdAulas_Click(object sender, EventArgs e)
        {

        }

        private void QntdAlunos_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void CadastraModalidade_Load(object sender, EventArgs e)
        {

        }
    }
}
